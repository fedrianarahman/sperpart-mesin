<div class="nav-header">
            <a href="index.php" class="brand-logo">
                <!-- <img class="logo-abbr" src="images/logo-white.png" alt=""> -->
                <!-- <img class="logo-compact" src="images/logo-text-white.png" alt=""> -->
                <!-- <img class="brand-title" src="./images/logo-fix.png" alt=""> -->
                <h1 class="brand-logo">Inventory Controll</h1>
                <!-- <h1 class="logo-compact">Inventory Controll</h1> -->
            </a>

            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>