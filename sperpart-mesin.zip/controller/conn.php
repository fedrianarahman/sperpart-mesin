<?php

$server = 'sql210.infinityfree.com';
$username = 'if0_36006255';
$password = 'U186iNLJhRKlm';
$db_name = 'if0_36006255_db_sidang_revisi';

$conn = mysqli_connect($server,$username,$password,$db_name);

if (!$conn) {
    echo "
    <script>alert('Database Belum Dikoneksikan')</script>
    ";
}

?>